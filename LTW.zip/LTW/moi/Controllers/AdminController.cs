﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using moi.Models;

namespace moi.Controllers
{
    public class AdminController : Controller
    {
        QL_BanGaRanEntities1 db = new QL_BanGaRanEntities1();

        private void CheckAdmin()
        {
            if (HttpContext.Session["Role"]?.ToString() != "Admin")
            {
                HttpContext.Response.Redirect(Url.Action("Login", "Account"), false);
                HttpContext.ApplicationInstance.CompleteRequest();
            }
        }

        public ActionResult Index()
        {
            CheckAdmin();
            ViewBag.TongSanPham = db.SanPhams.Count();
            ViewBag.TongLoai = db.LoaiSanPhams.Count();
            ViewBag.TongHoaDon = db.HoaDons.Count();
            ViewBag.TongKhachHang = db.KhachHangs.Count();

            ViewBag.TongDoanhThu = db.HoaDons
                .Where(h => h.TrangThai == "Hoàn tất")
                .Sum(h => (decimal?)(h.TongTien ?? 0)) ?? 0;

            return View();
        }

        public ActionResult SanPham()
        {
            CheckAdmin();
            var list = db.SanPhams
                         .Include("LoaiSanPham")
                         .ToList();
            return View(list);
        }

        [HttpGet]
        public ActionResult ThemSanPham()
        {
            ViewBag.ListLoai = new SelectList(db.LoaiSanPhams.ToList(), "MaLoai", "TenLoai");
            return View();
        }

        [HttpPost]
        public ActionResult ThemSanPham(SanPham sp, HttpPostedFileBase Anh)
        {
            if (ModelState.IsValid)
            {
                if (Anh != null && Anh.ContentLength > 0)
                {
                    string fileName = Path.GetFileName(Anh.FileName);
                    string path = Path.Combine(Server.MapPath("~/Content/HinhAnhSP/"), fileName);
                    Anh.SaveAs(path);
                    sp.Anh = fileName;
                }

                db.SanPhams.Add(sp);
                db.SaveChanges();
                return RedirectToAction("SanPham");
            }

            ViewBag.ListLoai = new SelectList(db.LoaiSanPhams.ToList(), "MaLoai", "TenLoai");
            return View(sp);
        }

        [HttpGet]
        public ActionResult SuaSanPham(int id)
        {
            var sp = db.SanPhams.Find(id);
            if (sp == null) return HttpNotFound();

            ViewBag.ListLoai = new SelectList(db.LoaiSanPhams.ToList(), "MaLoai", "TenLoai", sp.MaLoai);
            return View(sp);
        }

        [HttpPost]
        public ActionResult SuaSanPham(SanPham sp, HttpPostedFileBase Anh)
        {
            if (ModelState.IsValid)
            {
                var existing = db.SanPhams.Find(sp.MaSP);
                if (existing == null) return HttpNotFound();

                existing.TenSP = sp.TenSP;
                existing.Gia = sp.Gia;
                existing.SoLuong = sp.SoLuong;
                existing.MaLoai = sp.MaLoai;
                existing.MoTa = sp.MoTa;

                if (Anh != null && Anh.ContentLength > 0)
                {
                    if (!string.IsNullOrEmpty(existing.Anh))
                    {
                        var oldPath = Path.Combine(Server.MapPath("~/Content/HinhAnhSP/"), existing.Anh);
                        if (System.IO.File.Exists(oldPath))
                            System.IO.File.Delete(oldPath);
                    }

                    string fileName = Path.GetFileName(Anh.FileName);
                    string path = Path.Combine(Server.MapPath("~/Content/HinhAnhSP/"), fileName);
                    Anh.SaveAs(path);
                    existing.Anh = fileName;
                }

                db.SaveChanges();
                return RedirectToAction("SanPham");
            }

            ViewBag.ListLoai = new SelectList(db.LoaiSanPhams.ToList(), "MaLoai", "TenLoai", sp.MaLoai);
            return View(sp);
        }

        [HttpPost]
        public ActionResult XoaSanPham(int id)
        {
            var sp = db.SanPhams.Find(id);
            if (sp == null) return Json(new { success = false, message = "Không tìm thấy sản phẩm!" });

            if (!string.IsNullOrEmpty(sp.Anh))
            {
                var path = Path.Combine(Server.MapPath("~/Content/HinhAnhSP/"), sp.Anh);
                if (System.IO.File.Exists(path))
                    System.IO.File.Delete(path);
            }

            db.SanPhams.Remove(sp);
            db.SaveChanges();

            return Json(new { success = true, message = "Xóa thành công!" });
        }

        public ActionResult DonHang(string mode = "thang")
        {
            CheckAdmin();

            var list = db.HoaDons
                  .Include(h => h.KhachHang)
                  .OrderByDescending(h => h.NgayLap)
                  .ToList();

            object data = null;

            if (mode == "ngay")
            {
                data = db.HoaDons
                         .Where(h => h.TrangThai == "Hoàn tất")
                         .GroupBy(h => h.NgayLap)
                         .Select(g => new
                         {
                             Ngay = g.Key,
                             TongTien = g.Sum(x => (decimal?)(x.TongTien ?? 0)) ?? 0
                         })
                         .OrderBy(x => x.Ngay)
                         .ToList();
            }
            else if (mode == "nam")
            {
                data = db.HoaDons
                         .Where(h => h.TrangThai == "Hoàn tất")
                         .GroupBy(h => h.NgayLap.Value.Year)
                         .Select(g => new
                         {
                             Nam = g.Key,
                             TongTien = g.Sum(x => (decimal?)(x.TongTien ?? 0)) ?? 0
                         })
                         .OrderBy(x => x.Nam)
                         .ToList();
            }
            else
            {
                data = db.HoaDons
                         .Where(h => h.TrangThai == "Hoàn tất")
                         .GroupBy(h => new { h.NgayLap.Value.Year, h.NgayLap.Value.Month })
                         .Select(g => new
                         {
                             Nam = g.Key.Year,
                             Thang = g.Key.Month,
                             TongTien = g.Sum(x => (decimal?)(x.TongTien ?? 0)) ?? 0
                         })
                         .OrderBy(x => x.Nam).ThenBy(x => x.Thang)
                         .ToList();
            }

            ViewBag.Mode = mode;
            ViewBag.ThongKe = data;
            return View(list);
        }

        [HttpGet]
        public ActionResult CapNhatDonHang(int? id)
        {
            CheckAdmin();
            var hd = db.HoaDons.Find(id);
            if (hd == null) return HttpNotFound();

            ViewBag.TrangThaiList = new SelectList(new[]
            {
                new { Value = "Chờ xác nhận", Text = "Chờ xác nhận" },
                new { Value = "Đang giao", Text = "Đang giao" },
                new { Value = "Hoàn tất", Text = "Hoàn tất" },
                new { Value = "Đã hủy", Text = "Đã hủy" }
            }, "Value", "Text", hd.TrangThai);

            var chiTiet = db.ChiTietHoaDons
                            .Where(ct => ct.MaHD == id)
                            .Include("SanPham")
                            .ToList();

            ViewBag.ChiTiet = chiTiet;
            return View(hd);
        }

        [HttpPost]
        public ActionResult CapNhatDonHang(HoaDon hd)
        {
            var existing = db.HoaDons.Find(hd.MaHD);
            if (existing == null) return HttpNotFound();

            existing.TrangThai = hd.TrangThai;

            var chiTiet = db.ChiTietHoaDons.Where(ct => ct.MaHD == hd.MaHD).ToList();
            existing.TongTien = chiTiet.Sum(x => (x.DonGia ?? 0) * (x.SoLuong ?? 0));

            db.SaveChanges();
            TempData["Success"] = "Cập nhật trạng thái & giá tiền hóa đơn thành công!";
            return RedirectToAction("DonHang");
        }
    }
}